class Animal:
    
    def __init__(self,Nombre,Peso):
        
        self.Nombre = Nombre
        self.Peso = Peso
        
    def mostrarnombre(self):
        
        print (f"el nombre del animal es: {self.Nombre}")
        
        
